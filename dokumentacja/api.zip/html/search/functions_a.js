var searchData=
[
  ['updatescan_392',['updateScan',['../class_scan_repository.html#a1f1efe6aa6387f41539744f5beded5d2',1,'ScanRepository\updateScan()'],['../class_scan_service.html#acc0185e5322f1b8b4df3e29eb4fd34d2',1,'ScanService\updateScan()']]],
  ['userlogin_393',['userLogin',['../class_login.html#ac030d51cd80e03cbd078f87e6164c7ac',1,'Login']]]
];
