var searchData=
[
  ['validatetokenexpiry_394',['validateTokenExpiry',['../class_security.html#abeb847b3a303e3ce39a997e4bd197936',1,'Security']]]
];
