var searchData=
[
  ['performauthorization_366',['performAuthorization',['../class_security.html#ae08e4e0ae754375af2539ed238721018',1,'Security']]]
];
