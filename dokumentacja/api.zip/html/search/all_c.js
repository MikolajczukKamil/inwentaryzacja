var searchData=
[
  ['performauthorization_144',['performAuthorization',['../class_security.html#ae08e4e0ae754375af2539ed238721018',1,'Security']]]
];
