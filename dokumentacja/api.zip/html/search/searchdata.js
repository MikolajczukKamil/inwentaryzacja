var indexSectionsWithContent =
{
  0: "$_abcdefgijlprstuv",
  1: "abdeilrstu",
  2: "abdegilrstu",
  3: "_acdfgjprsuv",
  4: "$f",
  5: "i"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "pages"
};

var indexSectionLabels =
{
  0: "Wszystko",
  1: "Struktury Danych",
  2: "Pliki",
  3: "Funkcje",
  4: "Zmienne",
  5: "Strony"
};

