var searchData=
[
  ['irepository_231',['IRepository',['../interface_i_repository.html',1,'']]],
  ['iservice_232',['IService',['../interface_i_service.html',1,'']]]
];
