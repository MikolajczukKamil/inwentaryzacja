/*
@licstart  The following is the entire license notice for the
JavaScript code in this file.

Copyright (C) 1997-2019 by Dimitri van Heesch

This program is free software; you can redistribute it and/or modify
it under the terms of version 2 of the GNU General Public License as published by
the Free Software Foundation

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License along
with this program; if not, write to the Free Software Foundation, Inc.,
51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

@licend  The above is the entire license notice
for the JavaScript code in this file
*/
var menudata={children:[
{text:"Strona główna",url:"index.html"},
{text:"Dodatkowe strony",url:"pages.html"},
{text:"Struktury Danych",url:"annotated.html",children:[
{text:"Struktury danych",url:"annotated.html"},
{text:"Indeks struktur danych",url:"classes.html"},
{text:"Hierarchia klas",url:"inherits.html"},
{text:"Pola danych",url:"functions.html",children:[
{text:"Wszystko",url:"functions.html",children:[
{text:"$",url:"functions.html#index__24"},
{text:"_",url:"functions__.html#index__5F"},
{text:"a",url:"functions_a.html#index_a"},
{text:"c",url:"functions_c.html#index_c"},
{text:"d",url:"functions_d.html#index_d"},
{text:"f",url:"functions_f.html#index_f"},
{text:"g",url:"functions_g.html#index_g"},
{text:"j",url:"functions_j.html#index_j"},
{text:"p",url:"functions_p.html#index_p"},
{text:"r",url:"functions_r.html#index_r"},
{text:"s",url:"functions_s.html#index_s"},
{text:"u",url:"functions_u.html#index_u"},
{text:"v",url:"functions_v.html#index_v"}]},
{text:"Funkcje",url:"functions_func.html",children:[
{text:"_",url:"functions_func.html#index__5F"},
{text:"a",url:"functions_func.html#index_a"},
{text:"c",url:"functions_func.html#index_c"},
{text:"d",url:"functions_func.html#index_d"},
{text:"f",url:"functions_func.html#index_f"},
{text:"g",url:"functions_func.html#index_g"},
{text:"j",url:"functions_func.html#index_j"},
{text:"p",url:"functions_func.html#index_p"},
{text:"r",url:"functions_func.html#index_r"},
{text:"s",url:"functions_func.html#index_s"},
{text:"u",url:"functions_func.html#index_u"},
{text:"v",url:"functions_func.html#index_v"}]},
{text:"Zmienne",url:"functions_vars.html",children:[
{text:"$",url:"functions_vars.html#index__24"}]}]}]},
{text:"Pliki",url:"files.html",children:[
{text:"Lista plików",url:"files.html"},
{text:"Globalne",url:"globals.html",children:[
{text:"Wszystko",url:"globals.html"},
{text:"Zmienne",url:"globals_vars.html"}]}]}]}
