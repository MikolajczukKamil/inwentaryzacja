var searchData=
[
  ['welcomeviewpage_351',['WelcomeViewPage',['../class_inwentaryzacja_1_1_welcome_view_page.html',1,'Inwentaryzacja.WelcomeViewPage'],['../class_inwentaryzacja_1_1_welcome_view_page.html#abfc8911c2b9000a8fafe2a18892b5730',1,'Inwentaryzacja.WelcomeViewPage.WelcomeViewPage()']]],
  ['welcomeviewpage_2examl_2ecs_352',['WelcomeViewPage.xaml.cs',['../_welcome_view_page_8xaml_8cs.html',1,'']]],
  ['welcomeviewpage_2examl_2eg_2ecs_353',['WelcomeViewPage.xaml.g.cs',['../_welcome_view_page_8xaml_8g_8cs.html',1,'']]]
];
