var searchData=
[
  ['welcomeviewpage_413',['WelcomeViewPage',['../class_inwentaryzacja_1_1_welcome_view_page.html',1,'Inwentaryzacja']]]
];
